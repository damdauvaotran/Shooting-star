#include "GlobalResource.h"



GlobalResource::GlobalResource() {
}


GlobalResource::~GlobalResource() {
}

